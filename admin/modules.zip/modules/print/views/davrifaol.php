<!DOCTYPE html>
<html lang="en">
	<head>
		<title><?=$page_info['title']?></title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
		<meta http-equiv="X-UA-Compatible" content="IE=edge" />
		<meta name="author" content="colorlib" />
		
		<link rel="stylesheet" type="text/css" href="<?=TMPL_URL?>css/my_style.css">
		<link rel="stylesheet" type="text/css" href="<?=TMPL_URL?>css/davrifaol.css">
	</head>
	
	<body>
		
		<div class="table-responsive davrifaol">
			
			<h3 class="center">
			Ҷадвали даври фаъоли донишҷӯёни 
			факултети <?=getFaculty($id_faculty)?>,<br>
			шакли таҳсил <?=getStudyView($id_s_v)?>,
			<?=getCourse($id_course)?>,
			<?=getSpecialtyCode($id_spec)?>,
			<?=getGroup($id_group)?>.<br>
			Дар соли таҳсили <?=$S_Y?> нимсолаи <?=$H_Y?>
			</h3>
			<table class="table">
				<thead class="center">
					<tr>
						<th rowspan="3"><div class="vertical">Миқдори донишҷӯён</div></th>
						<th rowspan="3"><div class="vertical">Роҳ наёфтанд</div></th>
						<th rowspan="3"><div class="vertical">Иштирок карданд</div></th>
						<th rowspan="3"><div class="vertical">Иштирок накарданд</div></th>
						<th colspan="14">Натиҷаи баҳоҳо</th>
					</tr>
					<tr>
						<th rowspan="2"><div class="vertical">Аъло</div></th>
						<th rowspan="2">%</th>
						
						<th rowspan="2"><div class="vertical">Хубу аъло</div></th>
						<th rowspan="2">%</th>
						
						<th rowspan="2"><div class="vertical">Хуб</div></th>
						<th rowspan="2">%</th>
						
						<th rowspan="2"><div class="vertical">Қаноатбахш</div></th>
						<th rowspan="2">%</th>
						
						<th rowspan="2"><div class="vertical">Омехта</div></th>
						<th rowspan="2">%</th>
						
						<th colspan="2"><div class="vertical">Қарздор</div></th>
						<th rowspan="2">%</th>
						
					</tr>
					<tr>
						<th>Fx</th>
						<th>F</th>
					</tr>
				</thead>
				<tbody class="center">
					<?php $result = getDavriFaol($id_student, $S_Y, $H_Y);?>
					<tr>
						<td><?=count($students)?></td>
						<td><?=count($nepodusk)?></td>
						<td><?=count($ishtirok_kardand)?></td>
						
						<td><?=count($students) - count($ishtirok_kardand)?></td>
						
						<td>
							<?=$result['5']?>
						</td>
						<td><?=round(($result['5'] * 100)/count($students), 1)?></td>
						
						<td><?=$result['45']?></td>
						<td><?=round(($result['45'] * 100)/count($students), 1)?></td>
						
						<td><?=$result['4']?></td>
						<td><?=round(($result['4'] * 100)/count($students), 1)?></td>
						
						<td><?=$result['3']?></td>
						<td><?=round(($result['3'] * 100)/count($students), 1)?></td>
						
						<td><?=$result['345']?></td>
						<td><?=round(($result['345'] *100)/count($students), 1)?></td>
						
						<td><?=$result['fx']?></td>
						<td><?=$result['f']?></td>
						<td><?=round((($result['fx'] + $result['f']) *100)/count($students), 1)?></td>
					</tr>
				</tbody>
			</table>
		</div>
	
	</body>
	
</html>