<div class="card-block">
	<i>Дохилкунии матн:</i><br>
	
	
	
	<label class="l_type2"><i>Ҷавоби дурустро дохил кунед:</i><br>
		<input type="text" placeholder="Ҷавоби дуруст" name="input_<?=$id_question;?>" class="form-control">
	</label>
</div>
