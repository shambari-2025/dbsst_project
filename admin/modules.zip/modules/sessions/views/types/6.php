<div class="card-block">
	<i>Дохилкунии адад:</i><br>
	
	<label class="l_type2"><i>Ҷавоби дурустро дохил кунед:</i><br>
		<input type="numer" placeholder="Ҷавоби дуруст" name="input_<?=$id_question;?>" class="form-control">
	</label>
</div>
