<?php

switch($option) {
	
	case "login":
		if(isset($_SESSION['user']['true'])){
			if($_SESSION['user']['access_type'] == 1){
				redirect(URL."admin/");
			}elseif($_SESSION['user']['access_type'] == 2){
				redirect(URL."teacher/");
			}elseif($_SESSION['user']['access_type'] == 3){
				redirect(URL."student/");
			}
		}
		$page_info['title'] = "Воридшавӣ";
		include("views/login.php");
		exit;
	break;
	
	case "auth":
		$login = clear_data($_POST['login']);
		$pswd = clear_data($_POST['password']);
		
		
		$check = select("users", "*", "`login` = '$login' AND `password` = '$pswd'", "id", false, "");
		
		if(!empty($check)){
			if($check[0]['access'] == 0){
				$_SESSION['message']['login'] = getMessage("NOT_ACCESS");
				redirect(URL);
			}else{
				$_SESSION['user']['true'] = true;
				$_SESSION['user']['id'] = $check[0]['id'];
				$_SESSION['user']['fullname_tj'] = $check[0]['fullname_tj'];
				$_SESSION['user']['fullname_ru'] = $check[0]['fullname_ru'];
				$_SESSION['user']['login'] = $check[0]['login'];
				$_SESSION['user']['birthday'] = $check[0]['birthday'];
				$_SESSION['user']['jins'] = $check[0]['jins'];
				$_SESSION['user']['photo'] = $check[0]['photo'];
				$_SESSION['user']['phone'] = $check[0]['phone'];
				$_SESSION['user']['access_type'] = $check[0]['access_type'];
				
				if(!isset($check[0]['first_login'])){
					$query = update_query("UPDATE `users` SET `first_login` = NOW() WHERE `id` = '".$check[0]['id']."'");
				}
				
				$query = update_query("UPDATE `users` SET `last_login` = NOW(), `counter` = `counter` + 1 WHERE `id` = '".$check[0]['id']."'");
				
				
				if($_SESSION['user']['access_type'] == 1){
					$_SESSION['user']['admin'] = true;
					redirect(URL."admin");
				}elseif($_SESSION['user']['access_type'] == 2){
					$_SESSION['user']['teacher'] = true;
					redirect(URL."teacher");
				}elseif($_SESSION['user']['access_type'] == 3){
					$_SESSION['user']['student'] = true;
					redirect(URL."student");
				}
			}
		}else{
			$_SESSION['message']['login'] = getMessage("LOGIN_FALSE");
			redirect(URL);
		}
	break;
	
	case "logout":
		
		unset($_SESSION['user']);
		unset($_SESSION['superarr']);
		redirect(URL);
	break;
	
}

?>