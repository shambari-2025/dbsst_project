<!DOCTYPE html>
<html lang="en">
<head>
    <title>Воридшавӣ ба барнома</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Вход в систему Донишгоҳи байналмилалии сайёҳӣ и соҳибкории Тоҷикистон">
    <meta name="keywords" content="донишгох, воридшави, Тоикистон, сайёхи">

    <!-- Подключение шрифта Playfair Display -->
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Roboto:wght@400&display=swap" rel="stylesheet">

    <link rel="icon" type="image/png" href="<?=URL?>userfiles/logo.ico"/>
    <link rel="stylesheet" type="text/css" href="<?=URL?>modules/login/views/vendor/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="<?=URL?>modules/login/views/fonts/font-awesome-4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="<?=URL?>modules/login/views/fonts/iconic/css/material-design-iconic-font.min.css">
    <link rel="stylesheet" type="text/css" href="<?=URL?>modules/login/views/vendor/animate/animate.css">
    <link rel="stylesheet" type="text/type" href="<?=URL?>modules/login/views/css/util.css">
    <link rel="stylesheet" type="text/type" href="<?=URL?>modules/login/views/css/main.css">

    <style>
        /* Основные стили */
        html, body {
            height: 100%;
            margin: 0;
            padding: 0;
            overflow-x: hidden;
            overflow-y: auto;
        }

        body {
            height: 100vh;
            position: relative;
            background-image: url('<?=URL?>userfiles/tut_bg.jpg');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
        }

        .limiter {
            height: 100%;
            position: relative;
        }

        .navbar {
            background: linear-gradient(90deg, rgba(0,0,0,0.5), rgba(139,94,60,0.5));
            backdrop-filter: blur(4px);
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
            padding: 15px 30px;
        }

        .navbar-collapse {
            justify-content: space-between;
        }

        .top-links {
            display: flex;
            justify-content: space-between;
            align-items: center;
            width: 100%;
        }

        .links-left {
            display: flex;
            gap: 40px;
        }

        .top-links a {
            color: white;
            text-decoration: none;
            font-family: 'Roboto', sans-serif;
            font-size: 18px;
            padding: 10px 18px;
            border-radius: 12px;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 10px;
            background-color: rgba(255, 255, 255, 0.05);
            box-shadow: 0 4px 10px rgba(0,0,0,0.2);
        }

        .top-links a:hover {
            background: rgba(255, 255, 255, 0.2);
            transform: scale(1.08);
        }

        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.2); }
            100% { transform: scale(1); }
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        @keyframes bounce {
            0%, 20%, 50%, 80%, 100% { transform: translateY(0); }
            40% { transform: translateY(-10px); }
            60% { transform: translateY(-5px); }
        }

        .top-links a i {
            font-size: 32px;
            color: #FF6347;
            transition: transform 1.0s ease, color 0.3s ease;
            animation: pulse 1.5s infinite;
        }

        .top-links a:hover i {
            animation: bounce 0.5s;
            color: #ffd700;
        }

        #show-login-form {
            background: linear-gradient(#FF0000, white, green);
            font-weight: bold;
        }

        #show-login-form:hover {
            background: linear-gradient(#222831, #ffd700, #8B5E3C);
            transform: scale(1.1);
        }

        #show-login-form i {
            color: #222831;
            animation: spin 3s linear infinite;
        }

        #show-login-form:hover i {
            color: #3d783c;
            animation: none;
        }

        /* Стиль окна входа */
        .login-form-container {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            width: 100vw;
            height: 100vh;
            background: rgba(0, 0, 0, 0.20); /* Затемнение фона */
            z-index: 1000;
            justify-content: center;
            align-items: center;
            overflow: auto; /* Добавлено для прокрутки на маленьких экранах */
        }

        .login-form-wrapper {
            background: linear-gradient(135deg, rgba(255, 255, 255, 0.1), rgba(139, 94, 60, 0.2)); /* Градиентный фон */
            backdrop-filter: blur(15px); /* Усиленное размытие */
            border: 2px solid rgba(255, 215, 0, 0.3); /* Золотистая рамка */
            border-radius: 30px; /* Скругленные углы */
            padding: 10px;
            width: 200px; /* Фиксированная ширина */
            max-width: 300px; /* Фиксированная максимальная ширина */
            min-width: 350px; /* Фиксированная минимальная ширина */
            box-shadow: 0 25px 10px rgba(0, 0, 0, 0.1), inset 0 0 10px rgba(255, 215, 0, 0.1); /* Тени и внутреннее свечение */
            animation: fadeIn 0.5s ease-out;
            position: relative;
            overflow: hidden; /* Для эффекта свечения */
        }

        /* Добавляем эффект свечения по краям */
        .login-form-wrapper::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 100%;
            height: 200%;
            background: radial-gradient(circle, rgba(255, 215, 0, 0.50) 0%, transparent 70%);
            animation: rotateGlow 10s linear infinite;
            pointer-events: none;
        }

        @keyframes rotateGlow {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-30px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .close-login-form {
            position: absolute;
            top: 15px;
            right: 15px;
            color: #ffd700;
            font-size: 36px;
            cursor: pointer;
            transition: transform 0.3s ease, color 0.3s ease;
            text-shadow: 0 0 5px rgba(255, 215, 0, 0.5);
        }

        .close-login-form:hover {
            color: #f98404;
            transform: rotate(90deg);
        }

        .login100-pic img {
            max-width: 50%;
            height: auto;
            filter: drop-shadow(0 5px 15px rgba(0, 0, 0, 0.1));
            transition: transform 0.3s ease;
        }

        .login100-pic img:hover {
            transform: scale(1.05);
        }

        .login100-form-title {
            font-family: 'Playfair Display', serif;
            font-size: 3.2rem;
            background: linear-gradient(45deg, #ffd700, #f98404);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            text-shadow: 2px 2px 10px rgba(0, 0, 0, 0.4);
            margin-bottom: 20px;
            text-align: center;
            letter-spacing: 1px;
        }

        .error {
            color: #ff5555;
            font-family: 'Roboto', sans-serif;
            font-size: 22px;
            text-align: center;
            margin-bottom: 25px;
            text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.3);
        }

        .wrap-input100 {
            position: relative;
            margin-bottom: 25px;
            background: rgba(255, 255, 255, 0.05);
            border-radius: 50px;
            padding: 5px;
            box-shadow: inset 0 2px 5px rgba(0, 0, 0, 0.2);
            transition: box-shadow 0.3s ease;
        }

        .wrap-input100:hover {
            box-shadow: inset 0 2px 10px rgba(255, 215, 0, 0.2);
        }

        .input100 {
            font-family: 'Roboto', sans-serif;
            font-size: 16px;
            padding: 12px 15px;
            color: #fff;
            background: transparent;
            border: none;
            border-radius: 50px;
            width: 100%;
            box-sizing: border-box;
            transition: all 0.3s ease;
        }

        .input100:focus {
            outline: none;
            box-shadow: 0 0 10px rgba(255, 215, 0, 0.5);
        }

        .focus-input100 {
            position: absolute;
            top: -10px;
            left: 15px;
            font-size: 12px;
            color: #ffd700;
            background: rgba(0, 0, 0, 0.5);
            padding: 2px 5px;
            border-radius: 5px;
            transition: all 0.3s ease;
        }

        .btn-show-pass {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
        }

        .btn-show-pass i {
            font-size: 20px;
            color: #ffd700;
            animation: pulse 1.5s infinite;
        }

        .btn-show-pass:hover i {
            animation: bounce 0.5s;
            color: #f98404;
        }

        .login100-form-btn {
            background: linear-gradient(45deg, #ffd700, #f98404);
            color: #fff;
            border: none;
            padding: 12px 20px;
            border-radius: 15px;
            font-size: 20px;
            font-family: 'Roboto', sans-serif;
            font-weight: bold;
            box-shadow: 0 5px 25px rgba(0, 0, 0, 0.3);
            transition: all 0.3s ease;
            width: 100%;
            display: block;
            text-align: center;
            text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.3);
        }

        .login100-form-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 0 20px rgba(255, 215, 0, 0.7);
            background: linear-gradient(45deg, #f98404, #ffd700);
        }

        .login100-form-btn:active {
            transform: translateY(0);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
        }

        /* Стили для часов и даты */
        .clock-container {
            position: absolute;
            top: 20%;
            left: 50%;
            transform: translate(-50%, -50%);
            text-align: center;
            z-index: 500;
            background: rgba(0, 0, 0, 0.0);
            backdrop-filter: blur(8px);
            padding: 20px 40px;
            border-radius: 20px;
            border: 1px solid rgba(255, 255, 255, 0.1);
        }

        .clock-time {
            font-family: 'Roboto', sans-serif;
            font-size: 6rem;
            color: #8af2ff;
            text-shadow: 2px 2px 8px rgba(0, 0, 0, 0.5);
            line-height: 1;
        }

        .clock-date {
            font-family: 'Roboto', sans-serif;
            font-size: 2.5rem;
            color: #8af2ff;
            text-shadow: 1px 1px 4px rgba(0, 0, 0, 0.5);
            line-height: 1;
        }

        /* Остальные стили без изменений */
        .container-login100 {
            display: flex;
            justify-content: center;
            align-items: flex-end;
            min-height: 100vh;
            padding: 15px;
            padding-bottom: 50px;
        }

        .wrap-login100 {
            width: 90%;
            max-width: 300px;
            background: linear-gradient(45deg, rgba(139, 94, 60, 0.4), rgba(200, 200, 255, 0.2), rgba(255, 255, 255, 0.4));
            border-radius: 50px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
            backdrop-filter: blur(4px);
            padding: 10px;
        }

        .wrap-login100:hover {
            cursor: pointer;
            transform: scale(1.02);
            transition: transform 0.3s ease;
        }

        .top-right-logo {
            position: absolute;
            top: 50px;
            right: 20px;
            text-align: center;
        }

        .top-right-logo img {
            max-width: 100%;
            height: auto;
        }

        .top-right-logo p {
            margin: 5px 0 0 0;
            font-size: 16px;
            color: #fff;
            text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.5);
        }

        .moving-text-container {
            position: fixed;
            bottom: 40px;
            left: 0;
            width: 100%;
            text-align: center;
            z-index: 100;
        }

        .moving-text {
            display: inline-block;
            color: #8af2ff;
            font-family: 'Playfair Display', serif;
            font-size: 2.3rem;
            font-weight: bold;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
            background: rgba(255, 255, 255, 0.1);
            padding: 10px 20px;
            border-radius: 10px;
            white-space: nowrap;
            animation: moveText 25s ease-in-out infinite alternate;
        }

        @keyframes moveText {
            0% { transform: translateX(-30%); }
            100% { transform: translateX(30%); }
        }

        /* Медиа-запросы */
        @media (max-width: 768px) {
            .navbar {
                padding: 10px 15px;
            }

            .top-links {
                flex-direction: column;
                align-items: flex-start;
            }

            .links-left {
                flex-direction: column;
                gap: 10px;
            }

            .top-links a {
                font-size: 16px;
                padding: 8px 12px;
            }

            .login100-form-title {
                font-size: 2.8rem;
            }

            .moving-text {
                font-size: 2.4rem;
                animation: none;
            }

            .login100-pic img {
                max-width: 60%;
            }

            .top-links a i,
            .btn-show-pass i,
            .moving-text {
                animation: none;
            }

            .clock-time {
                font-size: 4rem;
            }

            .clock-date {
                font-size: 1.8rem;
            }

            .clock-container {
                padding: 15px 30px;
            }
        }

        @media (max-width: 576px) {
            .login-form-wrapper {
                padding: 40px; /* Оставляем фиксированные отступы */
                width: 400px; /* Фиксированная ширина */
                max-width: 400px;
                min-width: 400px;
            }

            .wrap-login100 {
                width: 95%;
                max-width: 250px;
            }

            .login100-form-btn {
                font-size: 18px;
                padding: 10px 15px;
            }

            .input100 {
                font-size: 16px;
                padding: 10px 12px;
            }

            .top-right-logo img {
                width: 80px;
            }

            .top-right-logo p {
                font-size: 14px;
            }

            .close-login-form {
                font-size: 30px;
            }

            .moving-text {
                font-size: 1.8rem;
            }

            .clock-time {
                font-size: 2.5rem;
            }

            .clock-date {
                font-size: 1.2rem;
            }

            .clock-container {
                padding: 10px 20px;
            }

            .login100-form-title {
                font-size: 2.5rem;
            }
        }
    </style>
</head>
<body>
    <div class="limiter">
        <!-- Навигация -->
        <nav class="navbar navbar-expand-lg navbar-dark">
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <div class="top-links">
                    <div class="links-left">
                        <a href="http://www.nlt.tj" target="_blank"><i class="fa fa-book"></i> Китобхонаи Миллӣ</a>
                        <a href="https://iutet.tj" target="_blank"><i class="fa fa-university"></i>Донишгоҳи байналмилалии сайёҳӣ ва соҳибкорӣ </a>
                        <a href="https://ntc.tj/tj" target="_blank"><i class="fa fa-check-square-o"></i> Маркази Миллии Тестӣ</a>
                        <a href="https://linkvideo.ru" target="_blank"><i class="fa fa-video-camera"></i> Назорати видеои</a>
                        <a href="https://web.telegram.org/k" target="_blank"><i class="fa fa-telegram"></i> Тамос: +992888182222</a>
                    </div>
                    <a href="#" id="show-login-form"><i class="fa fa-sign-in"></i> Воридшавӣ</a>
                </div>
            </div>
        </nav>

        <!-- Часы и дата в одном окне -->
        <div class="clock-container">
            <div id="clock-time" class="clock-time"></div>
            <div id="clock-date" class="clock-date"></div>
        </div>

        <!-- Форма входа -->
        <div class="login-form-container" id="login-form-container">
            <div class="login-form-wrapper">
                <span class="close-login-form" id="close-login-form">×</span>
                <form action="<?=URL?>?option=auth" method="post" class="login100-form validate-form">
                    <div class="login100-pic js-tilt" data-tilt>
                        <img src="<?=URL?>userfiles/logo.png" alt="<?=UNI_NAME?>" loading="lazy" style="display: block; margin: auto;">
                    </div>
                    <br>
                    <span class="login100-form-title p-b-26">Воридшавӣ</span>
                    <?php if(isset($_SESSION['message']['login'])):?>
                        <p class="error"><?=$_SESSION['message']['login'];?><?php unset($_SESSION['message']['login']);?></p>
                    <?php endif;?>
                    <div class="wrap-input100 validate-input" data-validate="Логинро ҳатман ворид кунед">
                        <input class="input100" type="text" name="login" placeholder="Логин" aria-label="Логин">
                        <span class="focus-input100" data-placeholder="Логин"></span>
                    </div>
                    <div class="wrap-input100 validate-input" data-validate="Паролро дохил кунед">
                        <span class="btn-show-pass"><i class="zmdi zmdi-eye"></i></span>
                        <input class="input100" type="password" name="password" placeholder="Парол" aria-label="Парол">
                        <span class="focus-input100" data-placeholder="Парол"></span>
                    </div>
                    <div class="container-login100-form-btn">
                        <div class="wrap-login100-form-btn">
                            <div class="login100-form-bgbtn"></div>
                            <button class="login100-form-btn" aria-label="Вход">Даромадан</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <div class="container-login100">
            <div class="wrap-login100">
                <!-- Основной блок -->
            </div>
        </div>

        <!-- Анимированный текст -->
        <div class="moving-text-container">
            <div class="moving-text">
                Донишгоҳи байналмилалии сайёҳӣ ва соҳибкории Тоҷикистон
            </div>
        </div>

        <!-- Логотип справа -->
        <div class="top-right-logo">
            <img src="<?=URL?>userfiles/logo." alt="Logo" loading="lazy">
            <p></p>
        </div>
    </div>

    <script src="<?=URL?>modules/login/views/vendor/jquery/jquery-3.2.1.min.js" async defer></script>
    <script src="<?=URL?>modules/login/views/vendor/animsition/js/animsition.min.js" async defer></script>
    <script src="<?=URL?>modules/login/views/vendor/bootstrap/js/popper.js" async defer></script>
    <script src="<?=URL?>modules/login/views/vendor/bootstrap/js/bootstrap.min.js" async defer></script>
    <script src="<?=URL?>modules/login/views/vendor/select2/select2.min.js" async defer></script>
    <script src="<?=URL?>modules/login/views/vendor/daterangepicker/moment.min.js" async defer></script>
    <script src="<?=URL?>modules/login/views/vendor/daterangepicker/daterangepicker.js" async defer></script>
    <script src="<?=URL?>modules/login/views/vendor/countdowntime/countdowntime.js" async defer></script>
    <script src="<?=URL?>modules/login/views/js/main.js" async defer></script>

    <script>
        document.getElementById('show-login-form').addEventListener('click', function(e) {
            e.preventDefault();
            document.getElementById('login-form-container').style.display = 'flex';
        });

        document.getElementById('close-login-form').addEventListener('click', function() {
            document.getElementById('login-form-container').style.display = 'none';
        });

        document.getElementById('login-form-container').addEventListener('click', function(e) {
            if (e.target === this) {
                this.style.display = 'none';
            }
        });

        // Скрипт для часов и даты
        function updateClock() {
            const now = new Date();
            
            // Форматируем время
            const hours = String(now.getHours()).padStart(2, '0');
            const minutes = String(now.getMinutes()).padStart(2, '0');
            const seconds = String(now.getSeconds()).padStart(2, '0');
            const timeString = `${hours}:${minutes}:${seconds}`;
            
            // Форматируем дату
            const day = String(now.getDate()).padStart(2, '0');
            const month = String(now.getMonth() + 1).padStart(2, '0');
            const year = now.getFullYear();
            const dateString = `${day}.${month}.${year}`;
            
            // Обновляем элементы
            document.getElementById('clock-time').textContent = timeString;
            document.getElementById('clock-date').textContent = dateString;
        }

        // Обновляем каждую секунду
        setInterval(updateClock, 1000);
        // Вызываем сразу
        updateClock();
    </script>
</body>
</html>