<div class="col-xl-12 col-md-12">
	
	<div class="card">
		<div class="card-block">
			<p class="text-c-red bold" style="text-align: center">Маълумот нест!</p>
		</div>
	</div>
</div>
