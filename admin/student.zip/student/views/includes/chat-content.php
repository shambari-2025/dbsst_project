<div class="showChat_inner">
	<div class="media chat-inner-header">
		<a class="back_chatBox">
			<i class="feather icon-x"></i> Раҷабзода Мансур
		</a>
	</div>
	
	
	<div class="chat-reply-box">
		<div class="right-icon-control">
			<div class="input-group input-group-button">
				<input type="text" class="form-control" placeholder="Мактуби Шумо... ">
				<div class="input-group-append">
					<button class="btn btn-primary waves-effect waves-light" type="button">
						<i class="feather icon-message-circle"></i>
					</button>
				</div>
			</div>
		</div>
	</div>
</div>