<div id="sidebar" class="users p-chat-user showChat">
	<div class="had-container">
		<div class="p-fixed users-main">
			<div class="user-box">
			
				<div class="chat-search-box">
					<a class="back_friendlist">
						<i class="feather icon-x"></i>
					</a>
					<div class="right-icon-control">
						<div class="input-group input-group-button">
							<input type="text" id="search-friends" name="footer-email" class="form-control" placeholder="Search Friend">
							<div class="input-group-append">
								<button class="btn btn-primary waves-effect waves-light" type="button">
									<i class="feather icon-search"></i>
								</button>
							</div>
						</div>
					</div>
				</div>
				
				<div class="main-friend-list">
					
					
				</div>
			</div>
		</div>
	</div>
</div>